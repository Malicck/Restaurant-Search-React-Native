import React, {useState, useEffect} from 'react';
import {View, StyleSheet, Text, Image} from 'react-native';
import yelp from '../api/yelp';
import {FlatList} from 'react-native-gesture-handler';

const ResultsShow = ({navigation}) => {
  const [results, setResults] = useState(null);
  const id = navigation.getParam('id');
  const getResults = async id => {
    const response = await yelp.get(`/${id}`);
    setResults(response.data);
  };
  useEffect(() => {
    getResults(id);
  }, []);
  if (!results) {
    return null;
  }
  return (
    <View>
      <Text style={styles.container}>{results.name}</Text>
      <FlatList
        data={results.photos}
        keyExtractor={photo => photo}
        renderItem={({item}) => {
          return (
            <Image
              style={{
                height: 250,
                width: '80%',
                alignSelf: 'center',
                margin: 8,
              }}
              source={{uri: item}}
            />
          );
        }}
      />
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    fontWeight: 'bold',
    fontSize: 18,
  },
});
export default ResultsShow;
