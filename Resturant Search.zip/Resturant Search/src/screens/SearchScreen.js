import React, {useState, useEffect} from 'react';
import {View, StyleSheet, Text} from 'react-native';
import SearchBar from '../components/SearchBar';
import useResults from '../hooks/useResults';
import ResultList from '../components/ResultList';
import {ScrollView} from 'react-native-gesture-handler';

const SearchScreen = () => {
  const [term, setTerm] = useState('');
  const [searchApi, results, error] = useResults();
  const findResultsByPrice = price => {
    //price==='$'|| price==='$$' ||price==='$$$'
    return results.filter(results => {
      return results.price === price;
    });
  };
  if (!results.length) {
    return null;
  }
  return (
    <View style={styles.container}>
      <ScrollView>
        <SearchBar
          term={term}
          onTermChange={setTerm}
          ontermSubmitted={() => searchApi(term)}
        />
        {/* <Text>we have found {results.length} results.</Text>
        <Text>{error}</Text> */}
        <ResultList results={findResultsByPrice('$')} title="Cost Effective" />
        <ResultList results={findResultsByPrice('$$')} title="Bit Pricer" />
        <ResultList results={findResultsByPrice('$$$')} title="Big Spender" />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    flex: 1,
    padding: 3,
    marginLeft: 4,
  },
});

export default SearchScreen;
