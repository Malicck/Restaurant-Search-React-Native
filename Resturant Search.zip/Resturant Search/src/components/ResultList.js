import React from 'react';
import {View, StyleSheet, Text} from 'react-native';
import {FlatList, TouchableOpacity} from 'react-native-gesture-handler';
import ResultsDetails from './ResultsDetails';
import {withNavigation} from 'react-navigation';
const ResultList = ({title, results, navigation}) => {
  return (
    <View>
      <Text style={styles.container}>{title}</Text>
      <Text>{results.length}</Text>
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={results}
        renderItem={({item}) => (
          <View>
            <TouchableOpacity
              onPress={() => navigation.navigate('Show', {id: item.id})}>
              <ResultsDetails results={item} />
            </TouchableOpacity>
          </View>
        )}
        keyExtractor={result => result.id}
      />
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    fontWeight: 'bold',
    fontSize: 18,
  },
});
export default withNavigation(ResultList);
