import React from 'react';
import {View, StyleSheet, Text, Image} from 'react-native';

const ResultsDetails = ({results}) => {
  return (
    <View>
      <Image source={{uri: results.image_url}} style={styles.img} />
      <Text style={styles.container}>{results.name}</Text>
      <Text style={{color: 'grey'}}>
        {results.rating} Stars, {results.review_count} Reviews
      </Text>
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    fontWeight: 'bold',
    fontSize: 15,
  },
  img: {
    height: 120,
    width: 250,
  },
});
export default ResultsDetails;
