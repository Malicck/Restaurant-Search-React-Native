import React from 'react';
import {View, StyleSheet, Text} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {TextInput} from 'react-native-gesture-handler';
const SearchBar = ({term, onTermChange, ontermSubmitted}) => {
  return (
    <View style={styles.SearchBar}>
      <Icon name="search" size={30} style={{marginTop: 7, marginLeft: 4}} />
      <TextInput
        style={{marginLeft: 10, padding: 4}}
        placeholder="Search"
        autoCorrect={false}
        placeholderTextColor="grey"
        style={{width: 250}}
        value={term}
        onChangeText={onTermChange}
        onEndEditing={ontermSubmitted}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  SearchBar: {
    backgroundColor: '#DCDCDC',
    alignSelf: 'center',
    width: 300,
    margin: 2,
    alignContent: 'center',
    height: 50,
    flexDirection: 'row',
    padding: 2,
    borderColor: '#DCDCDC',
    borderWidth: 1,
    borderRadius: 8,
  },
});
export default SearchBar;
