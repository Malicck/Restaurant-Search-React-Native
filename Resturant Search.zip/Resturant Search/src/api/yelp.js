import axios from 'axios';

export default axios.create({
  baseURL: 'https://api.yelp.com/v3/businesses',
  headers: {
    Authorization:
      'Bearer 2AgRPqvbv97fD-8uxKIeeX4MYXwNRWDC3LkGujPDEoQ8S8A8b-cYqEOQIZsB8AZ9QJ3WoeMXfTx8KVN8vEU6D02p485Z07Wg665ht7vMBccRCsRKSSRIQokKtG3_XnYx',
  },
});
